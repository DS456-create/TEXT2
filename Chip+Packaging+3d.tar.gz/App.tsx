import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  RotateCcw, ZoomIn, ZoomOut, Layers, Scissors, MousePointer2,
  Cpu, Radio, CircuitBoard, Network, BookOpen, Eye, FileText, Gauge,
  ChevronRight, Info, Move3d, Hand
} from "lucide-react";

/* ---------------- Types ---------------- */
type Part = {
  id: string;
  name: string;
  en: string;
  desc: string;
  spec: string;
  x: number; y: number; z: number;
  w: number; d: number; h: number;
  color: string;
  explode: number;
  shape?: "box" | "ball" | "cyl" | "lens";
};

type ModuleDef = {
  id: string;
  tab: string;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  overview: string;
  section: string;
  example: string;
  specs: { k: string; v: string }[];
  code: string[];
  parts: Part[];
};

const C = {
  silver: "#c9ccd4", gold: "#d9a441", green: "#2e7d4f", darkGreen: "#1e5c38",
  copper: "#c47b3a", pcb: "#256d46", glass: "#9fd4e8",
  silicon: "#7d8aa5", teal: "#2a9d8f",
  purple: "#6c5b9e", blue: "#3a6ea5", fiber: "#f2c94c",
};

function ballGrid(cx: number, cy: number, z: number, n: number, gap: number, color: string, explode: number, prefix: string): Part[] {
  const out: Part[] = [];
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
    out.push({
      id: `${prefix}-${i}-${j}`, name: "焊球 BGA Ball", en: "Solder Ball",
      desc: "共晶錫球，提供晶片與主機板之間的電氣連接與機械支撐，迴焊後形成可靠接點。",
      spec: "SAC305 · Ø 0.4 mm", x: cx + (i - (n - 1) / 2) * gap, y: cy + (j - (n - 1) / 2) * gap,
      z, w: 0.34, d: 0.34, h: 0.34, color, explode, shape: "ball",
    });
  }
  return out;
}

const MODULES: ModuleDef[] = [
  {
    id: "chip", tab: "2. 封裝晶片", title: "封裝晶片 QFN / BGA", subtitle: "Package · Die · Substrate",
    icon: <Cpu size={20} />,
    overview: "封裝是晶片的「盔甲與翻譯官」：保護脆弱的裸晶（Die），同時把奈米級的晶片接點，轉換成毫米級、可以焊接到電路板上的端子。點選 3D 模型上的零件，查看每個結構的功能。",
    section: "剖面由上而下：塑封膠體 → 裸晶 → 打線/覆晶接合 → 基板多層走線 → 焊球陣列。熱量主要經由裸晶背面與基板銅層向外擴散。",
    example: "手機處理器、電源管理 IC 常見 QFN 封裝；高腳數的 CPU、GPU 則使用 BGA，以面陣列焊球換取上千個 I/O。",
    specs: [
      { k: "封裝形式", v: "QFN / BGA" }, { k: "腳距 Pitch", v: "0.4 – 0.8 mm" },
      { k: "基板層數", v: "4 – 8 層" }, { k: "熱阻 θJA", v: "25 °C/W" },
    ],
    code: ["PKG  := QFN-48 / BGA-256", "DIE  := 3.2 × 3.2 mm", "WIRE := Au Ø25µm", "BALL := SAC305 Ø0.4", "Tj(max) := 125 °C"],
    parts: [
      { id: "mold", name: "塑封膠體", en: "Mold Compound", desc: "環氧樹脂塑封料，隔絕濕氣與外力，是晶片的第一道防線。", spec: "EMC · Tg 150°C", x: 0, y: 0, z: 2.55, w: 7.4, d: 7.4, h: 0.9, color: "#3c4048", explode: 4 },
      { id: "die", name: "裸晶 Die", en: "Silicon Die", desc: "真正執行運算的矽晶片，表面有上萬個微米級接點（Pad）。試著點它！", spec: "3.2 × 3.2 × 0.2 mm", x: 0, y: 0, z: 2.05, w: 3.4, d: 3.4, h: 0.45, color: C.silver, explode: 3 },
      { id: "wire", name: "打線 / 底膠", en: "Wire Bond · Underfill", desc: "金線把晶片接點連到基板；覆晶封裝則以凸塊（Bump）直連，並用底膠分散熱應力。", spec: "Au wire Ø 25 µm", x: 0, y: 0, z: 1.72, w: 4.6, d: 4.6, h: 0.28, color: C.gold, explode: 2 },
      { id: "sub", name: "封裝基板", en: "Package Substrate", desc: "多層有機基板，內部走線像一座立體城市，把晶片的微細線路扇出（Fan-out）到焊球。", spec: "BT resin · 4L", x: 0, y: 0, z: 1.05, w: 8, d: 8, h: 0.8, color: C.green, explode: 1 },
      { id: "sublayer", name: "基板內層銅", en: "Inner Cu Layers", desc: "基板內部的電源/接地平面與訊號層，降低阻抗並提供屏蔽。", spec: "Cu 18 µm / layer", x: 0, y: 0, z: 0.72, w: 7.6, d: 7.6, h: 0.3, color: C.copper, explode: 1 },
      ...ballGrid(0, 0, 0.1, 5, 1.5, "#d7dae2", 0, "ball"),
    ],
  },
  {
    id: "osfp", tab: "3. 光收發模組", title: "光收發模組 OSFP 800G", subtitle: "Optical Transceiver · PIC + EIC",
    icon: <Radio size={20} />,
    overview: "800G 光模組把電訊號變成光、在光纖裡跑幾百公尺、再變回電訊號。核心是光子晶片（PIC）與電晶片（EIC）的精密對位封裝，誤差必須小於一根頭髮的百分之一。",
    section: "剖面路徑：光纖 → 透鏡耦合 → PIC 光波導 → 光電二極體/TIA → EIC DSP → 金手指連接器。散熱鰭片直接壓在外殼上。",
    example: "AI 資料中心裡，每台交換器插滿 OSFP 模組連接數千張 GPU；一條 800G 鏈路等於 8 條 100G 光通道。",
    specs: [
      { k: "速率", v: "800 Gb/s (8×100G)" }, { k: "波長", v: "1310 nm" },
      { k: "功耗", v: "≈ 15 W" }, { k: "耦合損耗", v: "< 1.5 dB" },
    ],
    code: ["FORM := OSFP 800G", "LANES := 8 × 100G PAM4", "PIC  := SiPh 1310nm", "EIC  := DSP 7nm", "LINK := DR8 / 500 m"],
    parts: [
      { id: "shell", name: "金屬外殼", en: "Metal Housing", desc: "鋅合金外殼兼具 EMI 屏蔽與散熱，鰭片把 15W 熱量帶走。", spec: "Zn alloy · finned", x: 0, y: 0, z: 2.4, w: 9, d: 5.4, h: 0.8, color: "#b9bec9", explode: 4 },
      { id: "fiber", name: "光纖輸入", en: "Fiber Array", desc: "8 通道光纖陣列（FAU），每根光纖芯徑只有 9 µm，對位精度 ±0.5 µm。", spec: "SMF-28 · 8ch", x: -6.4, y: 0, z: 1.55, w: 3.4, d: 1.1, h: 1.1, color: C.fiber, explode: 2, shape: "cyl" },
      { id: "lens", name: "耦合透鏡", en: "Coupling Lens", desc: "微透鏡把光纖出來的光聚焦進 PIC 波導，是整個模組對位最關鍵的一步。", spec: "f = 0.3 mm", x: -4.2, y: 0, z: 1.55, w: 1.2, d: 1.2, h: 1.2, color: C.glass, explode: 3, shape: "lens" },
      { id: "pic", name: "光子晶片 PIC", en: "Photonic IC", desc: "矽光子晶片：調變器把電訊號刻到光上，光電二極體負責接收。", spec: "SiPh · 1310 nm", x: -1.8, y: 0, z: 1.5, w: 3.2, d: 2.6, h: 0.5, color: C.blue, explode: 2 },
      { id: "eic", name: "電晶片 EIC / DSP", en: "Electronic IC", desc: "DSP 晶片做 PAM4 編解碼與時鐘恢復，是模組裡最耗電的零件。", spec: "DSP · 7 nm", x: 1.6, y: 0, z: 1.5, w: 3, d: 3, h: 0.5, color: C.purple, explode: 2 },
      { id: "pcb2", name: "模組電路板", en: "Module PCB", desc: "高頻板材承載 100G 差動訊號，走線長度匹配誤差以皮秒計。", spec: "Megtron-7 · 12L", x: 0.4, y: 0, z: 0.85, w: 8.4, d: 4.6, h: 0.5, color: C.pcb, explode: 1 },
      { id: "finger", name: "金手指連接器", en: "Edge Connector", desc: "與交換器 Cage 連接的電氣介面，800G 訊號從這裡進出。", spec: "OSFP MSA", x: 5.6, y: 0, z: 0.95, w: 1.6, d: 3.6, h: 0.7, color: C.gold, explode: 1 },
    ],
  },
  {
    id: "pcb", tab: "4. PCB載板", title: "PCB 載板", subtitle: "Substrate · Copper Layers · Vias",
    icon: <CircuitBoard size={20} />,
    overview: "載板是晶片與主機板之間的「轉接城市」：用多層銅走線、雷射微孔（Via）把晶片的高密度接點，一層層扇出到大尺寸電路板。",
    section: "剖面可見：防焊綠漆 → 表層銅走線 → 介電層 → 內層電源面，微孔像電梯一樣連接各樓層。",
    example: "ABF 載板是 CPU 封裝的關鍵材料，線寬/線距已細到 10 µm 以下，接近半導體製程等級。",
    specs: [
      { k: "材料", v: "ABF / BT" }, { k: "線寬線距", v: "10 / 10 µm" },
      { k: "微孔徑", v: "50 µm" }, { k: "層數", v: "2-2-2 起疊" },
    ],
    code: ["STACK := 2-2-2 ABF", "L/S   := 10/10 µm", "VIA   := Ø50 µm laser", "MASK  := PSR green", "FINISH:= ENIG"],
    parts: [
      { id: "comp", name: "表面元件", en: "SMT Components", desc: "被動元件與小 IC 焊在載板表面，完成電源去耦與訊號調理。", spec: "0201 / QFN", x: -2.2, y: -1.6, z: 2.1, w: 1.8, d: 1.2, h: 0.7, color: "#40454e", explode: 4 },
      { id: "comp2", name: "表面元件 II", en: "SMT Components", desc: "另一顆表面元件，與相鄰走線保持安全間距避免短路。", spec: "0402 R/C", x: 2.4, y: 1.4, z: 2.1, w: 1.5, d: 1, h: 0.6, color: "#565d68", explode: 4 },
      { id: "mask", name: "防焊層", en: "Solder Mask", desc: "綠色防焊漆只露出焊墊，防止迴焊時錫橋短路——PCB 的經典綠色就來自它。", spec: "PSR · LPI", x: 0, y: 0, z: 1.78, w: 9, d: 6.4, h: 0.22, color: "#2f8f57", explode: 3 },
      { id: "cu1", name: "表層銅走線", en: "Top Cu Traces", desc: "表層高速走線，差動對等長繞線像蛇一樣，是訊號完整性的關鍵。", spec: "Cu 12 µm", x: 0, y: 0, z: 1.5, w: 8.8, d: 6.2, h: 0.18, color: C.copper, explode: 2 },
      { id: "diel", name: "介電層", en: "Dielectric (ABF)", desc: "味之素 ABF 絕緣膜，層間絕緣同時提供雷射鑽孔的平坦表面。", spec: "ABF GX-T31", x: 0, y: 0, z: 1.18, w: 8.8, d: 6.2, h: 0.4, color: "#e8e0cc", explode: 2 },
      { id: "cu2", name: "內層電源面", en: "Power Plane", desc: "整片銅面供應電源與接地，低阻抗是晶片穩定供電的基礎（PI）。", spec: "Cu plane 18 µm", x: 0, y: 0, z: 0.8, w: 8.8, d: 6.2, h: 0.18, color: "#a8642c", explode: 1 },
      { id: "core", name: "核心基材", en: "Core", desc: "BT 樹脂核心提供機械強度，貫穿孔（PTH）連接上下兩側。", spec: "BT core 0.4 mm", x: 0, y: 0, z: 0.3, w: 9, d: 6.4, h: 0.55, color: "#7a4a21", explode: 0 },
      { id: "via1", name: "雷射微孔", en: "Laser Via", desc: "50 µm 雷射孔連接相鄰層，是高密度扇出的垂直通道。點它看看！", spec: "Ø 50 µm", x: -3, y: 1.8, z: 1.35, w: 0.5, d: 0.5, h: 1.1, color: "#e8b34b", explode: 2, shape: "cyl" },
      { id: "via2", name: "雷射微孔 II", en: "Laser Via", desc: "交錯式（Staggered）微孔避免應力集中，提高可靠度。", spec: "Ø 50 µm", x: 3.2, y: -1.8, z: 1.35, w: 0.5, d: 0.5, h: 1.1, color: "#e8b34b", explode: 2, shape: "cyl" },
    ],
  },
  {
    id: "cpo", tab: "5. CPO中介層", title: "CPO 中介層", subtitle: "Co-Packaged Optics · Interposer",
    icon: <Network size={20} />,
    overview: "CPO（共封裝光學）把光引擎直接封進交換器晶片封裝裡，電訊號只走幾毫米就變成光——這是 AI 資料中心壓低功耗的終極武器。核心是矽中介層與 TSV。",
    section: "剖面：Switch ASIC 坐在矽中介層上，TSV 矽穿孔垂直貫穿中介層連到底下基板，8 顆光引擎環繞四周。",
    example: "51.2T 交換器若用傳統可插拔模組要耗電上千瓦；CPO 可把每 bit 功耗砍半以上。",
    specs: [
      { k: "交換容量", v: "51.2 Tb/s" }, { k: "光引擎", v: "8 × 6.4T" },
      { k: "TSV 孔徑", v: "10 µm" }, { k: "功耗/bit", v: "< 5 pJ" },
    ],
    code: ["SWITCH := 51.2T ASIC", "ENGINES:= 8 × 6.4T SiPh", "INTERP := Si + TSV", "FIBER  := detachable FAU", "P/bit  := < 5 pJ"],
    parts: [
      { id: "asic", name: "Switch ASIC 主晶片", en: "Switch ASIC", desc: "中央大型交換晶片，負責 51.2T 流量交換，是封裝的心臟。", spec: "≈ 800 mm² die", x: 0, y: 0, z: 2.2, w: 4.6, d: 4.6, h: 0.7, color: C.silicon, explode: 3 },
      ...([-3.4, 0, 3.4].map((v, i) => ({
        id: `eng-t${i}`, name: "光引擎 Optical Engine", en: "Optical Engine",
        desc: "矽光引擎把 ASIC 的電訊號轉成光，從封裝邊緣送進光纖。",
        spec: "6.4 Tb/s / engine", x: v, y: -3.6, z: 2.05, w: 2.2, d: 1.8, h: 0.55, color: C.teal, explode: 3,
      })) as Part[]),
      ...([-3.4, 3.4].map((v, i) => ({
        id: `eng-s${i}`, name: "光引擎 Optical Engine", en: "Optical Engine",
        desc: "環繞 ASIC 的光引擎群，縮短電走線距離、大幅降低功耗。",
        spec: "6.4 Tb/s / engine", x: v, y: 0, z: 2.05, w: 1.8, d: 2.2, h: 0.55, color: "#238277", explode: 3,
      })) as Part[]),
      ...([-3.4, 0, 3.4].map((v, i) => ({
        id: `eng-b${i}`, name: "光引擎 Optical Engine", en: "Optical Engine",
        desc: "8 顆光引擎合計 51.2T，與 ASIC 共封裝在同一中介層上。",
        spec: "6.4 Tb/s / engine", x: v, y: 3.6, z: 2.05, w: 2.2, d: 1.8, h: 0.55, color: "#238277", explode: 3,
      })) as Part[]),
      { id: "interp", name: "矽中介層", en: "Silicon Interposer", desc: "超大矽片做成的「轉接板」，上有比頭髮細十倍的走線連接所有晶片。", spec: "Si · RDL 2 µm", x: 0, y: 0, z: 1.45, w: 10.4, d: 10.4, h: 0.45, color: "#95a3bd", explode: 2 },
      { id: "tsv1", name: "TSV 矽穿孔", en: "Through-Silicon Via", desc: "垂直貫穿矽中介層的銅柱，把訊號與電源送到下方基板，是 3D 封裝的電梯。", spec: "Ø 10 µm Cu", x: -4.2, y: -4.2, z: 1.0, w: 0.45, d: 0.45, h: 1.3, color: C.copper, explode: 1, shape: "cyl" },
      { id: "tsv2", name: "TSV 矽穿孔 II", en: "Through-Silicon Via", desc: "數萬根 TSV 並行工作，頻寬密度是傳統打線的一百倍。", spec: "Ø 10 µm Cu", x: 4.2, y: 4.2, z: 1.0, w: 0.45, d: 0.45, h: 1.3, color: C.copper, explode: 1, shape: "cyl" },
      { id: "base", name: "封裝基板", en: "Package Substrate", desc: "最下層有機基板，承載整個 CPO 封裝並連接到交換器主機板。", spec: "Organic · 12L", x: 0, y: 0, z: 0.35, w: 11.4, d: 11.4, h: 0.7, color: C.darkGreen, explode: 0 },
    ],
  },
];

/* ---------------- 2D fallback helpers ---------------- */
type Pt = { x: number; y: number };
function shade(hex: string, f: number): string {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.min(255, Math.max(0, Math.round(((n >> 16) & 255) * f)));
  const g = Math.min(255, Math.max(0, Math.round(((n >> 8) & 255) * f)));
  const b = Math.min(255, Math.max(0, Math.round((n & 255) * f)));
  return `rgb(${r},${g},${b})`;
}

const THREE_CDN = "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js";

export default function App() {
  const [modIdx, setModIdx] = useState(0);
  const [tab, setTab] = useState<"概览" | "剖面图" | "示例" | "规格">("概览");
  const [selected, setSelected] = useState<string | null>(null);
  const [explode, setExplode] = useState(0);
  const [section, setSection] = useState(false);
  const [angle, setAngle] = useState(-0.6);
  const [zoom, setZoom] = useState(30);
  const [threeStatus, setThreeStatus] = useState<"loading" | "ready" | "failed">("loading");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const threeMountRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ on: boolean; x: number; moved: boolean }>({ on: false, x: 0, moved: false });
  const polys = useRef<{ id: string; pts: Pt[] }[]>([]);
  const mod = MODULES[modIdx];
  const selPart = useMemo(() => mod.parts.find((p) => p.id === selected) ?? null, [mod, selected]);

  const uniqueParts = useMemo(() => {
    const seen = new Map<string, Part>();
    mod.parts.forEach((p) => { if (!seen.has(p.name)) seen.set(p.name, p); });
    return [...seen.values()];
  }, [mod]);

  useEffect(() => { setSelected(null); }, [modIdx]);

  /* ---- Load three.js r128 as global THREE ---- */
  useEffect(() => {
    const w = window as any;
    if (w.THREE) { setThreeStatus("ready"); return; }
    const s = document.createElement("script");
    s.src = THREE_CDN;
    s.async = true;
    s.onload = () => setThreeStatus((window as any).THREE ? "ready" : "failed");
    s.onerror = () => setThreeStatus("failed");
    document.head.appendChild(s);
    return () => { s.onload = null; s.onerror = null; };
  }, []);

  /* ---- Three.js scene ---- */
  const threeRef = useRef<any>(null);
  const stateRef = useRef({ angle, zoom, explode, section, selected });
  stateRef.current = { angle, zoom, explode, section, selected };

  const buildModuleGroup = (THREE: any, m: ModuleDef) => {
    const group = new THREE.Group();
    const meshes: any[] = [];
    const addEdges = (mesh: any, geo: any) => {
      const edges = new THREE.LineSegments(
        new THREE.EdgesGeometry(geo),
        new THREE.LineBasicMaterial({ color: 0x2b2620, transparent: true, opacity: 0.35 })
      );
      mesh.add(edges);
    };
    m.parts.forEach((p) => {
      let geo: any;
      if (p.shape === "ball") geo = new THREE.SphereGeometry(p.w / 2, 20, 14);
      else if (p.shape === "lens") geo = new THREE.SphereGeometry(p.w / 2, 24, 18);
      else if (p.shape === "cyl") geo = new THREE.CylinderGeometry(p.w / 2, p.w / 2, p.h, 20);
      else geo = new THREE.BoxGeometry(p.w, p.h, p.d);
      const mat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(p.color), roughness: 0.5, metalness: 0.28,
        transparent: p.shape === "lens", opacity: p.shape === "lens" ? 0.72 : 1,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(p.x, p.z + p.h / 2, p.y);
      if (p.shape === "lens") mesh.scale.set(1, 0.72, 1);
      if (p.shape === "cyl" && p.w > p.d * 1.5) mesh.rotation.z = Math.PI / 2;
      mesh.userData.part = p;
      if (p.shape !== "ball" && p.shape !== "lens") addEdges(mesh, geo);
      group.add(mesh);
      meshes.push(mesh);
    });
    // numbered hotspot markers (up to 9)
    const seen = new Map<string, Part>();
    m.parts.forEach((p) => { if (!seen.has(p.name)) seen.set(p.name, p); });
    [...seen.values()].slice(0, 9).forEach((p, i) => {
      const cv = document.createElement("canvas"); cv.width = 96; cv.height = 96;
      const g = cv.getContext("2d")!;
      g.beginPath(); g.arc(48, 48, 40, 0, Math.PI * 2);
      g.fillStyle = "#fbf8f1"; g.fill();
      g.lineWidth = 7; g.strokeStyle = "#b4552d"; g.stroke();
      g.fillStyle = "#b4552d"; g.font = "bold 46px sans-serif";
      g.textAlign = "center"; g.textBaseline = "middle";
      g.fillText(String(i + 1), 48, 50);
      const tex = new THREE.CanvasTexture(cv);
      const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
      spr.scale.set(1.05, 1.05, 1);
      spr.position.set(p.x, p.z + p.h + 0.85, p.y);
      spr.userData.part = p;
      spr.userData.isMarker = true;
      group.add(spr);
      meshes.push(spr);
    });
    return { group, meshes };
  };

  const applyThreeState = () => {
    const t = threeRef.current; if (!t) return;
    const { explode: ex, section: sec, selected: sel } = stateRef.current;
    const modId = t.modId;
    t.meshes.forEach((mesh: any) => {
      const p: Part = mesh.userData.part;
      if (mesh.userData.isMarker) {
        mesh.position.y = p.z + p.h + 0.85 + p.explode * ex * 0.011;
        const hidden = sec && (modId === "pcb"
          ? (p.id === "mask" || p.id === "comp" || p.id === "comp2")
          : p.explode >= 3);
        mesh.visible = !hidden;
        return;
      }
      mesh.position.y = p.z + p.h / 2 + p.explode * ex * 0.011;
      const hidden = sec && (modId === "pcb"
        ? (p.id === "mask" || p.id === "comp" || p.id === "comp2")
        : p.explode >= 3);
      mesh.visible = !hidden;
      if (mesh.material && mesh.material.emissive) {
        const isSel = sel === p.id;
        mesh.material.emissive.setHex(isSel ? 0xb4552d : 0x000000);
        mesh.material.emissiveIntensity = isSel ? 0.55 : 0;
      }
    });
  };

  useEffect(() => {
    if (threeStatus !== "ready") return;
    const mount = threeMountRef.current; if (!mount) return;
    const THREE = (window as any).THREE; if (!THREE) { setThreeStatus("failed"); return; }

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mount.appendChild(renderer.domElement);
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    renderer.domElement.style.display = "block";

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 300);
    const grid = new THREE.GridHelper(44, 44, 0xcbbd9d, 0xd8cfba);
    grid.material.transparent = true; grid.material.opacity = 0.55;
    scene.add(grid);
    scene.add(new THREE.AmbientLight(0xfff4e0, 0.75));
    const dir = new THREE.DirectionalLight(0xffffff, 0.85);
    dir.position.set(14, 22, 10);
    scene.add(dir);
    const dir2 = new THREE.DirectionalLight(0xdfe8ff, 0.3);
    dir2.position.set(-12, 8, -14);
    scene.add(dir2);

    const { group, meshes } = buildModuleGroup(THREE, MODULES[modIdx]);
    scene.add(group);
    threeRef.current = { renderer, scene, camera, group, meshes, modId: MODULES[modIdx].id, raycaster: new THREE.Raycaster(), THREE };
    applyThreeState();

    const resize = () => {
      const wpx = mount.clientWidth || 1, hpx = mount.clientHeight || 1;
      renderer.setSize(wpx, hpx, false);
      camera.aspect = wpx / hpx;
      camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(mount);

    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const st = stateRef.current;
      group.rotation.y = st.angle;
      const dist = Math.min(46, Math.max(14, 62 - st.zoom));
      camera.position.set(dist * 0.72, dist * 0.58, dist * 0.72);
      camera.lookAt(0, 1.1, 0);
      renderer.render(scene, camera);
    };
    loop();

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.dispose();
      if (renderer.domElement.parentNode === mount) mount.removeChild(renderer.domElement);
      threeRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [threeStatus]);

  /* rebuild model when module changes */
  useEffect(() => {
    const t = threeRef.current; if (!t) return;
    const THREE = t.THREE;
    t.scene.remove(t.group);
    const { group, meshes } = buildModuleGroup(THREE, mod);
    t.group = group; t.meshes = meshes; t.modId = mod.id;
    t.scene.add(group);
    applyThreeState();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mod]);

  useEffect(() => { applyThreeState(); }, [explode, section, selected, mod]);

  const pickThree = (e: React.MouseEvent) => {
    const t = threeRef.current; if (!t) return;
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const v = new t.THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1
    );
    t.raycaster.setFromCamera(v, t.camera);
    const hits = t.raycaster.intersectObjects(t.meshes.filter((m: any) => m.visible), false);
    if (hits.length > 0) setSelected(hits[0].object.userData.part.id);
    else setSelected(null);
  };

  /* ---- 2D isometric fallback (only if CDN three.js cannot load) ---- */
  useEffect(() => {
    if (threeStatus === "ready") return;
    const cv = canvasRef.current; if (!cv) return;
    const ctx = cv.getContext("2d"); if (!ctx) return;
    const W = cv.width, H = cv.height;
    ctx.clearRect(0, 0, W, H);
    const dark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    ctx.strokeStyle = dark ? "rgba(160,145,110,0.18)" : "rgba(150,135,100,0.25)";
    ctx.lineWidth = 1;
    for (let x = 0; x < W; x += 26) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
    for (let y = 0; y < H; y += 26) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }

    const cos = Math.cos(angle), sin = Math.sin(angle);
    const proj = (x: number, y: number, z: number): Pt => {
      const rx = x * cos - y * sin, ry = x * sin + y * cos;
      return { x: W / 2 + rx * zoom, y: H * 0.62 + ry * zoom * 0.5 - z * zoom * 0.82 };
    };
    const drawPoly = (pts: Pt[], fill: string, stroke = "rgba(40,32,20,0.35)") => {
      ctx.beginPath(); pts.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
      ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); ctx.strokeStyle = stroke; ctx.stroke();
    };

    const items = mod.parts.map((p) => {
      const ez = p.z + p.explode * explode * 0.028;
      return { p, ez, depth: (p.x * sin + p.y * cos) };
    }).sort((a, b) => a.depth - b.depth);

    polys.current = [];
    ctx.fillStyle = dark ? "rgba(0,0,0,0.35)" : "rgba(90,75,50,0.18)";
    ctx.beginPath(); ctx.ellipse(W / 2, H * 0.66, 6.2 * zoom, 1.7 * zoom, 0, 0, Math.PI * 2); ctx.fill();

    for (const { p, ez } of items) {
      if (section && p.explode >= 3 && mod.id !== "pcb") continue;
      if (section && mod.id === "pcb" && (p.id === "mask" || p.id === "comp" || p.id === "comp2")) continue;
      const isSel = selected === p.id;
      const hw = p.w / 2, hd = p.d / 2, z0 = ez, z1 = ez + p.h;
      const c = [[-hw, -hd], [hw, -hd], [hw, hd], [-hw, hd]].map(([dx, dy]) => proj(p.x + dx, p.y + dy, z0));
      const t = [[-hw, -hd], [hw, -hd], [hw, hd], [-hw, hd]].map(([dx, dy]) => proj(p.x + dx, p.y + dy, z1));
      const base = isSel ? "#e07b4a" : p.color;
      if (p.shape === "ball" || p.shape === "lens") {
        const ctr = proj(p.x, p.y, z1);
        ctx.beginPath(); ctx.arc(ctr.x, ctr.y, p.w * zoom * 0.42, 0, Math.PI * 2);
        ctx.fillStyle = shade(base.startsWith("#") ? base : "#cccccc", 1.05); ctx.fill();
        ctx.strokeStyle = "rgba(40,32,20,0.4)"; ctx.stroke();
        ctx.beginPath(); ctx.arc(ctr.x - 3, ctr.y - 4, p.w * zoom * 0.14, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(255,255,255,0.65)"; ctx.fill();
        polys.current.push({ id: p.id, pts: [{ x: ctr.x - 14, y: ctr.y - 14 }, { x: ctr.x + 14, y: ctr.y - 14 }, { x: ctr.x + 14, y: ctr.y + 14 }, { x: ctr.x - 14, y: ctr.y + 14 }] });
      } else {
        drawPoly([c[1], c[2], t[2], t[1]], shade(base.startsWith("#") ? base : "#999999", 0.72));
        drawPoly([c[2], c[3], t[3], t[2]], shade(base.startsWith("#") ? base : "#999999", 0.55));
        drawPoly(t, shade(base.startsWith("#") ? base : "#bbbbbb", 1.08), isSel ? "#b4552d" : "rgba(40,32,20,0.35)");
        if (isSel) { ctx.lineWidth = 2.5; drawPoly(t, "rgba(224,123,74,0.25)", "#b4552d"); ctx.lineWidth = 1; }
        polys.current.push({ id: p.id, pts: t });
      }
    }
    ctx.font = "bold 11px sans-serif";
    uniqueParts.slice(0, 9).forEach((p, i) => {
      const rep = mod.parts.find((q) => q.name === p.name)!;
      const ez = rep.z + rep.explode * explode * 0.028 + rep.h;
      const pt = proj(rep.x, rep.y, ez);
      ctx.beginPath(); ctx.arc(pt.x, pt.y - 16, 9, 0, Math.PI * 2);
      ctx.fillStyle = selected === rep.id ? "#b4552d" : (dark ? "#29241b" : "#fbf8f1");
      ctx.fill(); ctx.strokeStyle = "#b4552d"; ctx.lineWidth = 1.6; ctx.stroke(); ctx.lineWidth = 1;
      ctx.fillStyle = selected === rep.id ? "#fff" : "#b4552d";
      ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText(String(i + 1), pt.x, pt.y - 16);
    });
  }, [mod, angle, zoom, explode, section, selected, uniqueParts, threeStatus]);

  const onClick2D = (e: React.MouseEvent) => {
    const rect = canvasRef.current!.getBoundingClientRect();
    const sx = canvasRef.current!.width / rect.width, sy = canvasRef.current!.height / rect.height;
    const mx = (e.clientX - rect.left) * sx, my = (e.clientY - rect.top) * sy;
    for (let i = polys.current.length - 1; i >= 0; i--) {
      const { id, pts } = polys.current[i];
      let inside = false;
      for (let a = 0, b = pts.length - 1; a < pts.length; b = a++) {
        if ((pts[a].y > my) !== (pts[b].y > my) && mx < ((pts[b].x - pts[a].x) * (my - pts[a].y)) / (pts[b].y - pts[a].y) + pts[a].x) inside = !inside;
      }
      if (inside) { setSelected(id); return; }
    }
    setSelected(null);
  };

  const resetView = () => { setAngle(-0.6); setZoom(30); setExplode(0); setSection(false); };
  const shellStyle = { boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)' } as const;
  const tabContent = tab === "概览" ? mod.overview : tab === "剖面图" ? mod.section : tab === "示例" ? mod.example : "";

  const dragHandlers = {
    onMouseDown: (e: React.MouseEvent) => { drag.current = { on: true, x: e.clientX, moved: false }; },
    onMouseMove: (e: React.MouseEvent) => {
      if (drag.current.on) {
        const dx = e.clientX - drag.current.x;
        if (Math.abs(dx) > 2) drag.current.moved = true;
        setAngle((a) => a + dx * 0.008);
        drag.current.x = e.clientX;
      }
    },
    onMouseUp: (e: React.MouseEvent) => {
      const wasDrag = drag.current.moved;
      drag.current.on = false;
      if (!wasDrag) { if (threeStatus === "ready") pickThree(e); else onClick2D(e); }
    },
    onMouseLeave: () => { drag.current.on = false; },
    onWheel: (e: React.WheelEvent) => setZoom((z) => Math.min(52, Math.max(16, z - Math.sign(e.deltaY) * 2))),
  };

  return (
    <div data-safe-area-inset-root className="paper-grid flex h-[100dvh] flex-col" style={shellStyle}>
      {/* Top bar */}
      <header data-safe-area-sticky-top style={{ top: "var(--safe-area-inset-top)" }} className="sticky z-20 border-b-2 border-[var(--ink)] bg-[var(--paper)] px-4 py-3">
        <div className="mx-auto flex max-w-[1500px] flex-wrap items-center gap-x-4 gap-y-1">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-md bg-[var(--accent)] text-white"><Cpu size={20} /></span>
            <h1 className="text-xl font-black tracking-wide sm:text-2xl">CHIP PACKAGING <span className="text-[var(--accent)]">入門</span></h1>
          </div>
          <p className="text-sm font-medium tracking-[0.3em] text-[var(--ink-soft)]">探索 · 理解 · 动手</p>
          <span className="mono ml-auto hidden rounded-full border border-[var(--line)] bg-[var(--panel)] px-3 py-1 text-xs text-[var(--ink-soft)] md:block">SEMICONDUCTOR ADVANCED PACKAGING · 互動 3D 教材</span>
        </div>
      </header>

      {/* Main 3-column */}
      <main className="mx-auto grid w-full max-w-[1500px] flex-1 grid-cols-1 gap-3 overflow-y-auto p-3 lg:grid-cols-[250px_1fr_320px] lg:overflow-hidden">
        {/* Left panel */}
        <aside className="order-2 flex flex-col rounded-lg border border-[var(--line)] bg-[var(--panel)] shadow-sm lg:order-1 lg:min-h-0">
          <div className="flex items-center gap-2 border-b border-[var(--line)] px-3 py-2 text-sm font-bold">
            <BookOpen size={16} className="text-[var(--accent)]" /> 元件清單
            <span className="mono ml-auto text-xs font-normal text-[var(--ink-soft)]">{uniqueParts.length} 項</span>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto p-2">
            {uniqueParts.map((p, i) => (
              <button key={p.name} onClick={() => setSelected(mod.parts.find((q) => q.name === p.name)!.id)}
                className={`mb-1 flex w-full items-center gap-2 rounded-md border px-2 py-2 text-left text-sm transition ${selected && mod.parts.find((q) => q.id === selected)?.name === p.name ? "border-[var(--accent)] bg-[var(--accent-soft)]" : "border-transparent hover:bg-[var(--paper-deep)]"}`}>
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-[var(--accent)] text-xs font-bold text-[var(--accent)]">{i + 1}</span>
                <span className="min-w-0">
                  <span className="block truncate font-semibold">{p.name}</span>
                  <span className="mono block truncate text-[11px] text-[var(--ink-soft)]">{p.en}</span>
                </span>
                <ChevronRight size={14} className="ml-auto shrink-0 text-[var(--ink-soft)]" />
              </button>
            ))}
          </div>
          {selPart && (
            <div className="border-t-2 border-[var(--accent)] bg-[var(--paper)] p-3">
              <p className="text-sm font-bold text-[var(--accent)]">{selPart.name}</p>
              <p className="mt-1 text-[13px] leading-relaxed">{selPart.desc}</p>
              <p className="mono mt-2 inline-block rounded bg-[var(--ink)] px-2 py-0.5 text-[11px] text-[var(--paper)]">{selPart.spec}</p>
            </div>
          )}
        </aside>

        {/* Center 3D */}
        <section className="order-1 flex min-h-[430px] flex-col rounded-lg border border-[var(--line)] bg-[var(--panel)] shadow-sm lg:order-2 lg:min-h-0">
          <div className="flex flex-wrap items-center gap-2 border-b border-[var(--line)] px-3 py-2">
            <span className="text-[var(--accent)]">{mod.icon}</span>
            <h2 className="text-base font-black">{mod.title}</h2>
            <span className="mono text-xs text-[var(--ink-soft)]">{mod.subtitle}</span>
            <span className="ml-auto flex items-center gap-1 text-xs text-[var(--ink-soft)]"><Move3d size={14} /> 拖曳旋轉 · 滾輪縮放 · 點零件看說明</span>
          </div>
          <div className="relative min-h-0 flex-1">
            {threeStatus === "ready" ? (
              <div ref={threeMountRef} className="h-full w-full cursor-grab touch-none active:cursor-grabbing" {...dragHandlers} />
            ) : (
              <canvas ref={canvasRef} width={860} height={520} className="h-full w-full cursor-grab touch-none active:cursor-grabbing" {...dragHandlers} />
            )}
            {threeStatus === "loading" && (
              <span className="mono absolute left-3 top-3 rounded bg-[var(--ink)] px-2 py-1 text-[11px] text-[var(--paper)]">three.js r128 載入中…</span>
            )}
            {threeStatus === "failed" && (
              <span className="mono absolute left-3 top-3 rounded bg-[var(--ink)] px-2 py-1 text-[11px] text-[var(--paper)]">離線模式：2D 等角投影</span>
            )}
            <div className="absolute bottom-3 right-3 flex gap-1.5">
              <button title="重設視角" onClick={resetView} className="flex h-9 w-9 items-center justify-center rounded-md border border-[var(--line)] bg-[var(--panel)] shadow hover:bg-[var(--accent-soft)]"><RotateCcw size={17} /></button>
              <button title="放大" onClick={() => setZoom((z) => Math.min(52, z + 3))} className="flex h-9 w-9 items-center justify-center rounded-md border border-[var(--line)] bg-[var(--panel)] shadow hover:bg-[var(--accent-soft)]"><ZoomIn size={17} /></button>
              <button title="縮小" onClick={() => setZoom((z) => Math.max(16, z - 3))} className="flex h-9 w-9 items-center justify-center rounded-md border border-[var(--line)] bg-[var(--panel)] shadow hover:bg-[var(--accent-soft)]"><ZoomOut size={17} /></button>
              <button title="爆炸圖" onClick={() => setExplode((v) => (v > 0 ? 0 : 100))} className={`flex h-9 w-9 items-center justify-center rounded-md border shadow ${explode > 0 ? "border-[var(--accent)] bg-[var(--accent)] text-white" : "border-[var(--line)] bg-[var(--panel)] hover:bg-[var(--accent-soft)]"}`}><Layers size={17} /></button>
              <button title="剖面" onClick={() => setSection((s) => !s)} className={`flex h-9 w-9 items-center justify-center rounded-md border shadow ${section ? "border-[var(--accent)] bg-[var(--accent)] text-white" : "border-[var(--line)] bg-[var(--panel)] hover:bg-[var(--accent-soft)]"}`}><Scissors size={17} /></button>
            </div>
            {section && <span className="mono absolute left-3 top-3 rounded bg-[var(--accent)] px-2 py-1 text-[11px] font-bold text-white">剖面模式：上層已移除</span>}
          </div>
          <div className="flex flex-wrap items-center gap-3 border-t border-[var(--line)] px-3 py-2">
            <label className="flex items-center gap-1 text-xs font-bold"><Layers size={14} className="text-[var(--accent)]" /> 爆炸圖</label>
            <input type="range" min={0} max={100} value={explode} onChange={(e) => setExplode(Number(e.target.value))} className="w-44 accent-[#b4552d]" aria-label="爆炸圖分離程度" />
            <span className="mono text-xs text-[var(--ink-soft)]">{explode}%</span>
            <span className="ml-auto flex items-center gap-1 text-xs text-[var(--ink-soft)]"><Hand size={14} /> {selPart ? `已選：${selPart.name}` : "點選模型零件或左側清單"}</span>
          </div>
        </section>

        {/* Right panel */}
        <aside className="order-3 flex flex-col rounded-lg border border-[var(--line)] bg-[var(--panel)] shadow-sm lg:min-h-0">
          <div className="grid grid-cols-4 border-b border-[var(--line)] text-center text-[13px] font-bold">
            {(["概览", "剖面图", "示例", "规格"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`flex items-center justify-center gap-1 py-2.5 ${tab === t ? "border-b-2 border-[var(--accent)] text-[var(--accent)]" : "text-[var(--ink-soft)] hover:text-[var(--ink)]"}`}>
                {t === "概览" ? <Eye size={13} /> : t === "剖面图" ? <Scissors size={13} /> : t === "示例" ? <FileText size={13} /> : <Gauge size={13} />}{t}
              </button>
            ))}
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto p-3">
            {tab === "规格" ? (
              <table className="w-full text-sm">
                <tbody>{mod.specs.map((s) => (
                  <tr key={s.k} className="border-b border-dashed border-[var(--line)]">
                    <td className="py-2 pr-2 font-semibold text-[var(--ink-soft)]">{s.k}</td>
                    <td className="mono py-2 text-right">{s.v}</td>
                  </tr>))}
                </tbody>
              </table>
            ) : (
              <p className="text-sm leading-relaxed">{tabContent}</p>
            )}
            {selPart && tab !== "规格" && (
              <div className="mt-3 rounded-md border border-[var(--accent)] bg-[var(--paper)] p-2.5">
                <p className="flex items-center gap-1 text-[13px] font-bold text-[var(--accent)]"><MousePointer2 size={13} /> {selPart.name}</p>
                <p className="mt-1 text-[13px] leading-relaxed">{selPart.desc}</p>
              </div>
            )}
            <div className="mt-4">
              <p className="mb-1.5 flex items-center gap-1 text-xs font-black tracking-wider text-[var(--ink-soft)]"><Info size={13} /> 动手试试 · 規格卡</p>
              <div className="mono rounded-md bg-[var(--ink)] p-3 text-[12px] leading-6 text-[#f0e7d3]">
                {mod.code.map((l) => <div key={l}><span className="text-[#e8a37c]">{l.split(":=")[0]}</span><span className="text-[#8a7f68]"> := </span>{l.split(":=")[1]}</div>)}
              </div>
              <p className="mt-2 text-xs leading-relaxed text-[var(--ink-soft)]">試著把爆炸圖拉到 100%，再點編號熱點，照著剖面順序把每一層念出來——面試時這就是你的答案骨架。</p>
            </div>
          </div>
        </aside>
      </main>

      {/* Bottom lesson tabs */}
      <nav className="border-t-2 border-[var(--ink)] bg-[var(--paper)] px-3 py-2.5">
        <div className="mx-auto grid max-w-[1500px] grid-cols-2 gap-2 sm:grid-cols-4">
          {MODULES.map((m, i) => (
            <button key={m.id} onClick={() => setModIdx(i)}
              className={`flex items-center gap-2 rounded-lg border-2 px-3 py-2.5 text-left transition ${i === modIdx ? "border-[var(--accent)] bg-[var(--accent)] text-white shadow" : "border-[var(--line)] bg-[var(--panel)] hover:border-[var(--accent)]"}`}>
              <span>{m.icon}</span>
              <span className="min-w-0">
                <span className="block truncate text-sm font-black">{m.tab}</span>
                <span className={`mono block truncate text-[10px] ${i === modIdx ? "text-white/80" : "text-[var(--ink-soft)]"}`}>{m.subtitle}</span>
              </span>
            </button>
          ))}
        </div>
        <p className="mx-auto mt-2 max-w-[1500px] text-center text-[11px] text-[var(--ink-soft)]">原創互動教材 · 靈感致敬 Learn Arduino（Dilum Sanjaya）· 為半導體封裝面試準備而作</p>
      </nav>
    </div>
  );
}
